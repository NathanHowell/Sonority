#!/bin/sh
if [ ! -f /jffs/sunrpc.o ]; then
    wget -O /jffs/sunrpc.o http://10.10.1.240/~build/nfs/sunrpc.o
    wget -O /jffs/lockd.o http://10.10.1.240/~build/nfs/lockd.o
    wget -O /jffs/nfs.o http://10.10.1.240/~build/nfs/nfs.o
fi

insmod /jffs/sunrpc.o
insmod /jffs/lockd.o
insmod /jffs/nfs.o

/bin/mount -t nfs -o nolock,soft,vers=2 10.20.1.12:/ /mnt
