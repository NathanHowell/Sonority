#!/bin/sh
if [ ! -f /jffs/sunrpc.o ]; then
    wget -O /jffs/sunrpc.o http://10.10.1.237/~holmgren/nfs/sunrpc.o
    wget -O /jffs/lockd.o http://10.10.1.237/~holmgren/nfs/lockd.o
    wget -O /jffs/nfs.o http://10.10.1.237/~holmgren/nfs/nfs.o
fi

insmod /jffs/sunrpc.o
insmod /jffs/lockd.o
insmod /jffs/nfs.o

/bin/mount -t nfs -o nolock,soft,vers=2 10.10.1.237:/home1 /mnt
